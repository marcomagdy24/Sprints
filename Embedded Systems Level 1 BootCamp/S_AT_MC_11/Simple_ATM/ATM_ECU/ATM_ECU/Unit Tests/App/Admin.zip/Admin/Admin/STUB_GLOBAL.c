/*
* STUB_GLOBAL.c
*
* Created: 8/5/2021 10:49:17 AM
*  Author: Mohamed Wagdy
*/
/*- INCLUDES -----------------------------------------------*/
#include "STUB_GLOBAL.h"

/*- STUB FUNCTION DECLARATIONS ----------------------------------*/

void GLOBALINTTERUPTS_Enable(void)
{

}

void GLOBALINTTERUPTS_Disable(void)
{

}